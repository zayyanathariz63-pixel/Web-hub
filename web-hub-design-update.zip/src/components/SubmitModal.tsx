import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Upload, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface SubmitModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SubmitModal: React.FC<SubmitModalProps> = ({ isOpen, onClose }) => {
  const { addWebsite } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    name: '',
    category: '',
    url: '',
    description: '',
    publisherEmail: '',
    imageUrl: '',
  });

  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleBlur = (field: string) => {
    setTouched(prev => ({ ...prev, [field]: true }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, imageUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  // Validation
  const isValidEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const isValidUrl = (url: string) => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };

  const errors = {
    name: !formData.name && touched.name,
    category: !formData.category && touched.category,
    url: (!formData.url || !isValidUrl(formData.url)) && touched.url,
    description: !formData.description && touched.description,
    publisherEmail: (!formData.publisherEmail || !isValidEmail(formData.publisherEmail)) && touched.publisherEmail,
    imageUrl: !formData.imageUrl && touched.imageUrl,
  };

  const isFormValid = 
    formData.name && 
    formData.category && 
    formData.url && isValidUrl(formData.url) &&
    formData.description && 
    formData.publisherEmail && isValidEmail(formData.publisherEmail) &&
    formData.imageUrl;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isFormValid) {
      addWebsite(formData);
      // Reset and close
      setFormData({
        name: '',
        category: '',
        url: '',
        description: '',
        publisherEmail: '',
        imageUrl: '',
      });
      setTouched({});
      onClose();
      // Optionally show success toast
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
              <h2 className="text-2xl font-bold text-white bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">
                Submit Website
              </h2>
              <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
                <X size={24} />
              </button>
            </div>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-4 flex gap-3">
                <AlertCircle className="text-amber-500 shrink-0" size={20} />
                <p className="text-sm text-slate-300">
                  Pastikan Anda memiliki izin untuk mempublikasikan website ini. 
                  Website tanpa izin akan dihapus.
                </p>
              </div>

              <form id="submit-form" onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Nama Website</label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      onBlur={() => handleBlur('name')}
                      className={`input-glass w-full ${errors.name ? 'border-red-500' : ''}`}
                      placeholder="Contoh: My Awesome Portfolio"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Kategori</label>
                    <select
                      name="category"
                      value={formData.category}
                      onChange={handleChange}
                      onBlur={() => handleBlur('category')}
                      className={`input-glass w-full ${errors.category ? 'border-red-500' : ''}`}
                    >
                      <option value="">Pilih Kategori</option>
                      <option value="Technology">Technology</option>
                      <option value="Design">Design</option>
                      <option value="Blog">Blog</option>
                      <option value="E-commerce">E-commerce</option>
                      <option value="Portfolio">Portfolio</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-300">URL Website</label>
                  <input
                    type="url"
                    name="url"
                    value={formData.url}
                    onChange={handleChange}
                    onBlur={() => handleBlur('url')}
                    className={`input-glass w-full ${errors.url ? 'border-red-500' : ''}`}
                    placeholder="https://example.com"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-300">Deskripsi</label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    onBlur={() => handleBlur('description')}
                    className={`input-glass w-full h-24 resize-none ${errors.description ? 'border-red-500' : ''}`}
                    placeholder="Jelaskan singkat mengenai website ini..."
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-300">Email Publisher <span className="text-amber-500">*</span></label>
                  <input
                    type="email"
                    name="publisherEmail"
                    value={formData.publisherEmail}
                    onChange={handleChange}
                    onBlur={() => handleBlur('publisherEmail')}
                    className={`input-glass w-full ${errors.publisherEmail ? 'border-red-500' : ''}`}
                    placeholder="email@anda.com"
                  />
                  <p className="text-xs text-slate-500">Wajib diisi untuk keperluan verifikasi.</p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-300">Thumbnail Website</label>
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className={`border-2 border-dashed ${errors.imageUrl ? 'border-red-500/50 bg-red-500/5' : 'border-slate-700 hover:border-amber-500/50 hover:bg-slate-800/50'} rounded-xl p-8 flex flex-col items-center justify-center cursor-pointer transition-all group`}
                  >
                    {formData.imageUrl ? (
                      <div className="relative w-full aspect-video rounded-lg overflow-hidden">
                        <img src={formData.imageUrl} alt="Preview" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <p className="text-white font-medium">Ganti Gambar</p>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="p-4 rounded-full bg-slate-800 group-hover:scale-110 transition-transform mb-4">
                          <Upload className="text-slate-400 group-hover:text-amber-500" size={24} />
                        </div>
                        <p className="text-slate-400 text-sm font-medium">Klik untuk upload gambar</p>
                        <p className="text-slate-500 text-xs mt-1">PNG, JPG, max 2MB</p>
                      </>
                    )}
                    <input 
                      type="file" 
                      ref={fileInputRef} 
                      className="hidden" 
                      accept="image/*"
                      onChange={handleFileChange}
                    />
                  </div>
                </div>
              </form>
            </div>

            {/* Footer */}
            <div className="p-6 border-t border-slate-800 bg-slate-900/80 backdrop-blur-md">
              <button
                type="submit"
                form="submit-form"
                disabled={!isFormValid}
                className={`w-full py-3 rounded-lg font-bold flex items-center justify-center gap-2 transition-all ${
                  isFormValid 
                    ? 'bg-amber-500 hover:bg-amber-600 text-slate-900 shadow-[0_0_20px_rgba(245,158,11,0.3)] hover:shadow-[0_0_30px_rgba(245,158,11,0.5)]' 
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {isFormValid ? <CheckCircle2 size={20} /> : null}
                Submit Website
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
