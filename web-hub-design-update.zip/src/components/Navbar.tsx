import React, { useState } from 'react';
import { Menu, RefreshCw, Shield, LayoutDashboard, Home, PlusCircle, MessageSquare } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { AnimatePresence, motion } from 'framer-motion';

interface NavbarProps {
  onOpenRules: () => void;
  onOpenSubmit: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenRules, onOpenSubmit }) => {
  const { 
    randomizeRecommendations, 
    openSuggestionModal, 
    openAdminLoginModal, 
    isAdminAuthenticated 
  } = useApp();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const handleRefresh = () => {
    randomizeRecommendations();
  };

  const handleAdminClick = () => {
    setIsMenuOpen(false);
    if (isAdminAuthenticated) {
      navigate('/admin');
    } else {
      openAdminLoginModal();
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-slate-700/50 h-16">
      <div className="container mx-auto px-4 h-full flex items-center justify-between">
        
        {/* Left: Hamburger & Logo */}
        <div className="flex items-center gap-4">
          <div className="relative">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 text-slate-300 hover:text-amber-400 transition-colors"
            >
              <Menu size={24} />
            </button>

            {/* Dropdown Menu */}
            <AnimatePresence>
              {isMenuOpen && (
                <>
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 bg-black/50 z-40"
                    onClick={() => setIsMenuOpen(false)}
                  />
                  <motion.div
                    initial={{ opacity: 0, y: -10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.95 }}
                    className="absolute top-full left-0 mt-2 w-48 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-50 overflow-hidden"
                  >
                    <div className="flex flex-col py-1">
                      <Link 
                        to="/" 
                        className="px-4 py-2 hover:bg-slate-700 flex items-center gap-2 text-sm text-slate-200"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <Home size={16} /> Home
                      </Link>
                      <button 
                        onClick={() => {
                          onOpenRules();
                          setIsMenuOpen(false);
                        }}
                        className="px-4 py-2 hover:bg-slate-700 flex items-center gap-2 text-sm text-slate-200 w-full text-left"
                      >
                        <Shield size={16} /> Peraturan
                      </button>
                      <button 
                        onClick={onOpenSubmit}
                        className="px-4 py-2 hover:bg-slate-700 flex items-center gap-2 text-sm text-slate-200 w-full text-left"
                      >
                        <PlusCircle size={16} /> Submit Website
                      </button>
                      <button 
                        onClick={() => {
                          openSuggestionModal();
                          setIsMenuOpen(false);
                        }}
                        className="px-4 py-2 hover:bg-slate-700 flex items-center gap-2 text-sm text-slate-200 w-full text-left"
                      >
                        <MessageSquare size={16} /> Kotak Saran
                      </button>
                      <button 
                        onClick={handleAdminClick}
                        className="px-4 py-2 hover:bg-slate-700 flex items-center gap-2 text-sm text-slate-200 w-full text-left"
                      >
                        <LayoutDashboard size={16} /> Admin Panel
                      </button>
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>

          <Link to="/" className="text-xl font-bold bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">
            WEB HUB
          </Link>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-3">
          {location.pathname === '/' && (
            <button 
              onClick={handleRefresh}
              className="p-2 text-slate-400 hover:text-green-400 transition-colors"
              title="Refresh Recommendations"
            >
              <RefreshCw size={20} />
            </button>
          )}
          
          <button 
            onClick={onOpenSubmit}
            className="hidden sm:flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold py-1.5 px-4 rounded-full text-sm transition-all shadow-lg shadow-amber-500/20"
          >
            <PlusCircle size={16} />
            Submit Web
          </button>
          
          <button 
            onClick={onOpenSubmit}
            className="sm:hidden p-2 text-amber-500 hover:text-amber-400"
          >
            <PlusCircle size={24} />
          </button>
        </div>
      </div>
    </nav>
  );
};
