import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
  isMandatory?: boolean; // If true, cannot close without clicking 'Understand'
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose, isMandatory = false }) => {
  const { rules, markRulesAsSeen } = useApp();

  const handleUnderstand = () => {
    markRulesAsSeen();
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={!isMandatory ? onClose : undefined}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative bg-slate-800 border border-slate-700 rounded-xl shadow-2xl w-full max-w-lg overflow-hidden"
          >
            {/* Header */}
            <div className="bg-amber-500/10 p-6 border-b border-slate-700 flex items-start gap-4">
              <div className="p-3 bg-amber-500/20 rounded-full text-amber-500 shrink-0">
                <AlertTriangle size={24} />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white mb-1">Peraturan Wajib</h2>
                <p className="text-slate-400 text-sm">Harap baca sebelum melanjutkan.</p>
              </div>
              {!isMandatory && (
                <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-white">
                  <X size={20} />
                </button>
              )}
            </div>

            {/* Content */}
            <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
              {rules.map((rule, index) => (
                <div key={rule.id} className="flex gap-3 text-slate-300">
                  <span className="font-bold text-amber-500">{index + 1}.</span>
                  <p>{rule.content}</p>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="p-6 border-t border-slate-700 bg-slate-900/50 flex justify-end">
              <button
                onClick={handleUnderstand}
                className="btn-gold w-full sm:w-auto"
              >
                Saya Mengerti
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
