import React, { useState } from 'react';
import { Send, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { motion, AnimatePresence } from 'framer-motion';

export const SuggestionBox: React.FC = () => {
  const { addSuggestion } = useApp();
  const [suggestion, setSuggestion] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const minLength = 100;
  const maxLength = 3000;
  const currentLength = suggestion.length;
  const isValid = currentLength >= minLength && currentLength <= maxLength;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isValid) {
      addSuggestion(suggestion);
      setSuggestion('');
      setIsSubmitted(true);
      setTimeout(() => setIsSubmitted(false), 3000);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto mt-16 mb-20 px-4">
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-700/50 rounded-2xl p-6 md:p-8 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-green-500/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>

        <div className="relative z-10">
          <h3 className="text-2xl font-bold text-white mb-2">Kotak Saran</h3>
          <p className="text-slate-400 mb-6">
            Punya masukan untuk Web Hub? Tulis di sini. (Min. {minLength} karakter)
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <textarea
                value={suggestion}
                onChange={(e) => setSuggestion(e.target.value)}
                maxLength={maxLength}
                className="w-full h-40 bg-slate-800/50 border border-slate-700 rounded-xl p-4 text-slate-200 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none resize-none transition-all placeholder:text-slate-600"
                placeholder="Tulis saran Anda di sini..."
              />
              <div className="absolute bottom-3 right-3 text-xs font-mono">
                <span className={`${currentLength < minLength ? 'text-slate-500' : 'text-green-400'}`}>
                  {currentLength}
                </span>
                <span className="text-slate-600"> / {maxLength}</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="text-xs text-slate-500">
                {currentLength > 0 && currentLength < minLength && (
                  <span className="text-amber-500">
                    Kurang {minLength - currentLength} karakter lagi.
                  </span>
                )}
              </div>

              <AnimatePresence mode="wait">
                {isSubmitted ? (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="flex items-center gap-2 text-green-400 font-medium"
                  >
                    <CheckCircle2 size={18} />
                    Terima kasih!
                  </motion.div>
                ) : (
                  <button
                    type="submit"
                    disabled={!isValid}
                    className={`flex items-center gap-2 px-6 py-2 rounded-lg font-bold transition-all duration-300 ${
                      isValid
                        ? 'bg-amber-500 hover:bg-amber-600 text-slate-900 shadow-[0_0_15px_rgba(245,158,11,0.2)] hover:shadow-[0_0_20px_rgba(245,158,11,0.4)]'
                        : 'bg-slate-800 text-slate-600 cursor-not-allowed'
                    }`}
                  >
                    <Send size={18} />
                    Kirim Saran
                  </button>
                )}
              </AnimatePresence>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
