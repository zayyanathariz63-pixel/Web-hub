import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Trash2, Edit, CheckCircle, XCircle, Search, Save, X, Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useNavigate } from 'react-router-dom';

export const Admin: React.FC = () => {
  const { 
    websites, 
    rules, 
    suggestions, 
    updateWebsiteStatus, 
    deleteWebsite, 
    addRule, 
    updateRule, 
    deleteRule,
    isAdminAuthenticated,
    openAdminLoginModal
  } = useApp();

  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'websites' | 'rules' | 'suggestions'>('websites');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Rules State
  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);
  const [newRuleContent, setNewRuleContent] = useState('');
  const [editRuleContent, setEditRuleContent] = useState('');

  // Suggestion View State
  const [viewSuggestion, setViewSuggestion] = useState<string | null>(null);

  // Confirmation Modal State
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [confirmAction, setConfirmAction] = useState<() => void>(() => {});
  const [confirmTitle, setConfirmTitle] = useState('');
  const [confirmMessage, setConfirmMessage] = useState('');

  // Auth Check
  useEffect(() => {
    if (!isAdminAuthenticated) {
      openAdminLoginModal();
      navigate('/');
    }
  }, [isAdminAuthenticated, navigate, openAdminLoginModal]);

  // Websites
  const filteredWebsites = websites.filter(w => 
    w.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    w.publisherEmail.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddRule = () => {
    if (newRuleContent.trim()) {
      addRule(newRuleContent);
      setNewRuleContent('');
    }
  };

  const handleUpdateRule = (id: string) => {
    if (editRuleContent.trim()) {
      updateRule(id, editRuleContent);
      setEditingRuleId(null);
    }
  };
  
  const handleDelete = (title: string, message: string, action: () => void) => {
    setConfirmTitle(title);
    setConfirmMessage(message);
    setConfirmAction(() => action);
    setIsConfirmOpen(true);
  };

  // Suggestions View Modal
  const selectedSuggestion = suggestions.find(s => s.id === viewSuggestion);

  return (
    <div className="container mx-auto px-4 py-8 pt-24 min-h-screen">
      <h1 className="text-3xl font-bold text-white mb-8">Admin Panel</h1>

      {/* Tabs */}
      <div className="flex gap-4 mb-8 border-b border-slate-700 pb-1 overflow-x-auto">
        {(['websites', 'rules', 'suggestions'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-medium capitalize transition-colors border-b-2 ${
              activeTab === tab 
                ? 'border-amber-500 text-amber-500' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'websites' && (
          <motion.div 
            key="websites"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-6"
          >
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="text"
                placeholder="Cari website atau email..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:border-amber-500 outline-none"
              />
            </div>

            <div className="overflow-x-auto bg-slate-900/50 rounded-xl border border-slate-800">
              <table className="w-full text-left text-sm text-slate-400">
                <thead className="bg-slate-800/50 text-xs uppercase font-medium text-slate-300">
                  <tr>
                    <th className="px-6 py-4">Website</th>
                    <th className="px-6 py-4">Publisher</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredWebsites.map(website => (
                    <tr key={website.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="px-6 py-4">
                        <div className="font-medium text-white">{website.name}</div>
                        <div className="text-xs text-slate-500 truncate max-w-[200px]">{website.url}</div>
                      </td>
                      <td className="px-6 py-4">{website.publisherEmail}</td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          website.status === 'active' 
                            ? 'bg-green-500/10 text-green-400 border border-green-500/20' 
                            : 'bg-red-500/10 text-red-400 border border-red-500/20'
                        }`}>
                          {website.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right space-x-2">
                        <button 
                          onClick={() => updateWebsiteStatus(website.id, website.status === 'active' ? 'inactive' : 'active')}
                          className={`p-1.5 rounded-lg transition-colors ${
                            website.status === 'active' 
                              ? 'text-amber-500 hover:bg-amber-500/10' 
                              : 'text-green-500 hover:bg-green-500/10'
                          }`}
                          title={website.status === 'active' ? 'Deactivate' : 'Activate'}
                        >
                          {website.status === 'active' ? <XCircle size={18} /> : <CheckCircle size={18} />}
                        </button>
                        <button 
                          onClick={() => handleDelete(
                            "Hapus Website", 
                            "Apakah Anda yakin ingin menghapus website ini? Tindakan ini tidak dapat dibatalkan.", 
                            () => deleteWebsite(website.id)
                          )}
                          className="p-1.5 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                          title="Delete"
                        >
                          <Trash2 size={18} />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {filteredWebsites.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-6 py-8 text-center text-slate-500">
                        Tidak ada website ditemukan.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {activeTab === 'rules' && (
          <motion.div 
            key="rules"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-6 max-w-3xl"
          >
            <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
              <h3 className="text-lg font-bold text-white mb-4">Tambah Peraturan Baru</h3>
              <div className="flex gap-3">
                <input
                  type="text"
                  value={newRuleContent}
                  onChange={e => setNewRuleContent(e.target.value)}
                  placeholder="Isi peraturan..."
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:border-amber-500 outline-none"
                />
                <button 
                  onClick={handleAddRule}
                  disabled={!newRuleContent.trim()}
                  className="bg-amber-500 hover:bg-amber-600 disabled:opacity-50 disabled:cursor-not-allowed text-slate-900 font-bold px-4 py-2 rounded-lg flex items-center gap-2"
                >
                  <Plus size={18} /> Tambah
                </button>
              </div>
            </div>

            <div className="flex gap-4 overflow-x-auto pb-4 snap-x snap-mandatory scroll-pl-4 custom-scrollbar">
              {rules.map((rule, index) => (
                <div key={rule.id} className="bg-slate-900/50 p-6 rounded-xl border border-slate-800 flex flex-col gap-4 min-w-[300px] w-[300px] snap-start relative group hover:border-amber-500/30 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="w-8 h-8 rounded-full bg-amber-500/10 text-amber-500 flex items-center justify-center text-sm font-bold border border-amber-500/20">
                      {index + 1}
                    </div>
                    <div className="flex gap-2">
                      {editingRuleId === rule.id ? (
                        <>
                          <button onClick={() => handleUpdateRule(rule.id)} className="p-2 bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30 transition-colors">
                            <Save size={18} />
                          </button>
                          <button onClick={() => setEditingRuleId(null)} className="p-2 bg-slate-700 text-slate-400 rounded-lg hover:bg-slate-600 transition-colors">
                            <X size={18} />
                          </button>
                        </>
                      ) : (
                        <>
                          <button 
                            onClick={() => {
                              setEditingRuleId(rule.id);
                              setEditRuleContent(rule.content);
                            }}
                            className="p-2 bg-slate-800 text-slate-400 rounded-lg hover:bg-amber-500/20 hover:text-amber-500 transition-colors"
                          >
                            <Edit size={18} />
                          </button>
                          <button 
                            onClick={() => handleDelete(
                              "",
                              "Menghapus peraturan tidak bisa dibatalkan.",
                              () => deleteRule(rule.id)
                            )}
                            className="p-2 bg-slate-800 text-slate-400 rounded-lg hover:bg-red-500/20 hover:text-red-500 transition-colors"
                          >
                            <Trash2 size={18} />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex-1">
                    {editingRuleId === rule.id ? (
                      <textarea
                        value={editRuleContent}
                        onChange={e => setEditRuleContent(e.target.value)}
                        className="w-full h-32 bg-slate-800 border border-amber-500/50 rounded-lg p-3 text-white outline-none resize-none text-sm"
                        autoFocus
                      />
                    ) : (
                      <p className="text-slate-300 text-sm leading-relaxed h-32 overflow-y-auto custom-scrollbar pr-2">{rule.content}</p>
                    )}
                  </div>
                </div>
              ))}
              
              {/* Add New Rule Card placeholder if needed, or just keep the list */}
              {rules.length === 0 && (
                <div className="w-full text-center py-12 text-slate-500">
                  Belum ada peraturan. Tambahkan di atas.
                </div>
              )}
            </div>
          </motion.div>
        )}

        {activeTab === 'suggestions' && (
          <motion.div 
            key="suggestions"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            {suggestions.map(suggestion => (
              <div key={suggestion.id} className="bg-slate-900/50 p-5 rounded-xl border border-slate-800 hover:border-slate-700 transition-colors flex flex-col h-full">
                <div className="text-xs text-slate-500 mb-3 font-mono">
                  {new Date(suggestion.createdAt).toLocaleDateString()}
                </div>
                <p className="text-slate-300 text-sm mb-4 line-clamp-3 flex-1">
                  {suggestion.content}
                </p>
                <button 
                  onClick={() => setViewSuggestion(suggestion.id)}
                  className="text-amber-500 hover:text-amber-400 text-sm font-medium self-start"
                >
                  Lihat Semua
                </button>
              </div>
            ))}
            {suggestions.length === 0 && (
              <div className="col-span-full text-center py-12 text-slate-500">
                Belum ada saran masuk.
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* View Suggestion Modal */}
      <AnimatePresence>
        {viewSuggestion && selectedSuggestion && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
              onClick={() => setViewSuggestion(null)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-slate-900 border border-slate-700 rounded-xl p-8 max-w-2xl w-full shadow-2xl"
            >
              <button 
                onClick={() => setViewSuggestion(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white"
              >
                <X size={24} />
              </button>
              <h3 className="text-xl font-bold text-white mb-2">Detail Saran</h3>
              <div className="text-xs text-slate-500 mb-6 font-mono border-b border-slate-800 pb-4">
                Diterima: {new Date(selectedSuggestion.createdAt).toLocaleString()}
              </div>
              <div className="max-h-[60vh] overflow-y-auto custom-scrollbar">
                <p className="text-slate-300 whitespace-pre-wrap leading-relaxed">
                  {selectedSuggestion.content}
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <ConfirmationModal
        isOpen={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        onConfirm={confirmAction}
        title={confirmTitle}
        message={confirmMessage}
      />
    </div>
  );
};
