import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const SuggestionModal: React.FC = () => {
  const { isSuggestionModalOpen, closeSuggestionModal, addSuggestion } = useApp();
  const [suggestion, setSuggestion] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const minLength = 100;
  const maxLength = 3000;
  const currentLength = suggestion.length;
  const isValid = currentLength >= minLength && currentLength <= maxLength;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isValid) {
      addSuggestion(suggestion);
      setSuggestion('');
      setIsSubmitted(true);
      setTimeout(() => {
        setIsSubmitted(false);
        closeSuggestionModal();
      }, 2000);
    }
  };

  return (
    <AnimatePresence>
      {isSuggestionModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            onClick={closeSuggestionModal}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
              <h2 className="text-xl font-bold text-white bg-gradient-to-r from-green-400 to-green-600 bg-clip-text text-transparent">
                Kotak Saran
              </h2>
              <button onClick={closeSuggestionModal} className="text-slate-400 hover:text-white transition-colors">
                <X size={24} />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 space-y-4">
              <p className="text-slate-400 text-sm">
                Punya masukan untuk Web Hub? Tulis di sini.
              </p>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="relative">
                  <textarea
                    value={suggestion}
                    onChange={(e) => setSuggestion(e.target.value)}
                    maxLength={maxLength}
                    className="w-full h-40 bg-slate-800/50 border border-slate-700 rounded-xl p-4 text-slate-200 focus:border-green-500 focus:ring-1 focus:ring-green-500 outline-none resize-none transition-all placeholder:text-slate-600"
                    placeholder="Tulis saran Anda di sini..."
                  />
                  <div className="absolute bottom-3 right-3 text-xs font-mono">
                    <span className={`${currentLength < minLength ? 'text-slate-500' : 'text-green-400'}`}>
                      {currentLength}
                    </span>
                    <span className="text-slate-600"> / {maxLength}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-xs text-slate-500">
                    {currentLength > 0 && currentLength < minLength && (
                      <span className="text-amber-500">
                        Kurang {minLength - currentLength} karakter lagi.
                      </span>
                    )}
                  </div>

                  <AnimatePresence mode="wait">
                    {isSubmitted ? (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="flex items-center gap-2 text-green-400 font-medium"
                      >
                        <CheckCircle2 size={18} />
                        Terima kasih!
                      </motion.div>
                    ) : (
                      <button
                        type="submit"
                        disabled={!isValid}
                        className={`flex items-center gap-2 px-6 py-2 rounded-lg font-bold transition-all duration-300 ${
                          isValid
                            ? 'bg-green-500 hover:bg-green-600 text-slate-900 shadow-[0_0_15px_rgba(16,185,129,0.2)] hover:shadow-[0_0_20px_rgba(16,185,129,0.4)]'
                            : 'bg-slate-800 text-slate-600 cursor-not-allowed'
                        }`}
                      >
                        <Send size={18} />
                        Kirim
                      </button>
                    )}
                  </AnimatePresence>
                </div>
              </form>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
