import React, { createContext, useContext, useState, useEffect } from 'react';

export interface Website {
  id: string;
  name: string;
  category: string;
  url: string;
  description: string;
  publisherEmail: string;
  imageUrl: string;
  status: 'active' | 'inactive';
}

export interface Rule {
  id: string;
  content: string;
}

export interface Suggestion {
  id: string;
  content: string;
  createdAt: string;
}

interface AppContextType {
  websites: Website[];
  rules: Rule[];
  suggestions: Suggestion[];
  hasSeenRules: boolean;
  addWebsite: (website: Omit<Website, 'id' | 'status'>) => void;
  updateWebsiteStatus: (id: string, status: 'active' | 'inactive') => void;
  deleteWebsite: (id: string) => void;
  addRule: (content: string) => void;
  updateRule: (id: string, content: string) => void;
  deleteRule: (id: string) => void;
  addSuggestion: (content: string) => void;
  markRulesAsSeen: () => void;
  randomizeRecommendations: () => void;
  recommendedWebsites: Website[];
  // Modal & Auth
  isSuggestionModalOpen: boolean;
  openSuggestionModal: () => void;
  closeSuggestionModal: () => void;
  isAdminLoginModalOpen: boolean;
  openAdminLoginModal: () => void;
  closeAdminLoginModal: () => void;
  isAdminAuthenticated: boolean;
  loginAdmin: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const INITIAL_RULES: Rule[] = [
  { id: '1', content: 'HATI-HATI: Jangan masukkan website milik orang lain tanpa izin.' },
  { id: '2', content: 'Jika belum mendapat izin, website akan dihapus dari Web Hub.' },
  { id: '3', content: 'Hubungi email: admin@webhub.id' },
];

const INITIAL_WEBSITES: Website[] = [
  {
    id: '1',
    name: 'Dev Community',
    category: 'Technology',
    url: 'https://dev.to',
    description: 'A constructive and inclusive social network for software developers.',
    publisherEmail: 'contact@dev.to',
    imageUrl: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
    status: 'active',
  },
  {
    id: '2',
    name: 'Dribbble',
    category: 'Design',
    url: 'https://dribbble.com',
    description: 'Discover the world’s top designers & creatives.',
    publisherEmail: 'support@dribbble.com',
    imageUrl: 'https://images.unsplash.com/photo-1558655146-d09347e0d7a8?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
    status: 'active',
  },
  {
    id: '3',
    name: 'Stack Overflow',
    category: 'Technology',
    url: 'https://stackoverflow.com',
    description: 'Empowering the world to develop technology through collective knowledge.',
    publisherEmail: 'team@stackoverflow.com',
    imageUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
    status: 'active',
  },
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [websites, setWebsites] = useState<Website[]>(() => {
    const saved = localStorage.getItem('webhub_websites');
    return saved ? JSON.parse(saved) : INITIAL_WEBSITES;
  });

  const [rules, setRules] = useState<Rule[]>(() => {
    const saved = localStorage.getItem('webhub_rules');
    return saved ? JSON.parse(saved) : INITIAL_RULES;
  });

  const [suggestions, setSuggestions] = useState<Suggestion[]>(() => {
    const saved = localStorage.getItem('webhub_suggestions');
    return saved ? JSON.parse(saved) : [];
  });

  const [hasSeenRules, setHasSeenRules] = useState<boolean>(() => {
    return localStorage.getItem('webhub_has_seen_rules') === 'true';
  });

  const [recommendationSeed, setRecommendationSeed] = useState<number>(Date.now());

  // Modal States
  const [isSuggestionModalOpen, setIsSuggestionModalOpen] = useState(false);
  const [isAdminLoginModalOpen, setIsAdminLoginModalOpen] = useState(false);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);

  useEffect(() => {
    localStorage.setItem('webhub_websites', JSON.stringify(websites));
  }, [websites]);

  useEffect(() => {
    localStorage.setItem('webhub_rules', JSON.stringify(rules));
  }, [rules]);

  useEffect(() => {
    localStorage.setItem('webhub_suggestions', JSON.stringify(suggestions));
  }, [suggestions]);

  useEffect(() => {
    localStorage.setItem('webhub_has_seen_rules', String(hasSeenRules));
  }, [hasSeenRules]);

  const addWebsite = (website: Omit<Website, 'id' | 'status'>) => {
    const newWebsite: Website = {
      ...website,
      id: Date.now().toString(),
      status: 'active',
    };
    setWebsites(prev => [...prev, newWebsite]);
  };

  const updateWebsiteStatus = (id: string, status: 'active' | 'inactive') => {
    setWebsites(prev => prev.map(w => w.id === id ? { ...w, status } : w));
  };

  const deleteWebsite = (id: string) => {
    setWebsites(prev => prev.filter(w => w.id !== id));
  };

  const addRule = (content: string) => {
    const newRule: Rule = { id: Date.now().toString(), content };
    setRules(prev => [...prev, newRule]);
  };

  const updateRule = (id: string, content: string) => {
    setRules(prev => prev.map(r => r.id === id ? { ...r, content } : r));
  };

  const deleteRule = (id: string) => {
    setRules(prev => prev.filter(r => r.id !== id));
  };

  const addSuggestion = (content: string) => {
    const newSuggestion: Suggestion = {
      id: Date.now().toString(),
      content,
      createdAt: new Date().toISOString(),
    };
    setSuggestions(prev => [newSuggestion, ...prev]);
  };

  const markRulesAsSeen = () => {
    setHasSeenRules(true);
  };

  const randomizeRecommendations = () => {
    setRecommendationSeed(Date.now());
  };

  // Memoized recommendations logic based on seed
  const recommendedWebsites = React.useMemo(() => {
    const activeWebsites = websites.filter(w => w.status === 'active');
    // Simple shuffle based on seed (conceptually)
    // In a real app, use a proper seedable PRNG or backend.
    // Here we just shuffle randomly whenever the seed changes.
    return [...activeWebsites].sort(() => Math.random() - 0.5).slice(0, 6);
  }, [websites, recommendationSeed]);

  return (
    <AppContext.Provider
      value={{
        websites,
        rules,
        suggestions,
        hasSeenRules,
        addWebsite,
        updateWebsiteStatus,
        deleteWebsite,
        addRule,
        updateRule,
        deleteRule,
        addSuggestion,
        markRulesAsSeen,
        randomizeRecommendations,
        recommendedWebsites,
        // Modal & Auth
        isSuggestionModalOpen,
        openSuggestionModal: () => setIsSuggestionModalOpen(true),
        closeSuggestionModal: () => setIsSuggestionModalOpen(false),
        isAdminLoginModalOpen,
        openAdminLoginModal: () => setIsAdminLoginModalOpen(true),
        closeAdminLoginModal: () => setIsAdminLoginModalOpen(false),
        isAdminAuthenticated,
        loginAdmin: () => setIsAdminAuthenticated(true),
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
