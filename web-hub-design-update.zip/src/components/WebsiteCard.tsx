import React from 'react';
import { ExternalLink, Tag } from 'lucide-react';
import { Website } from '../context/AppContext';
import { motion } from 'framer-motion';

interface WebsiteCardProps {
  website: Website;
  index: number;
}

export const WebsiteCard: React.FC<WebsiteCardProps> = ({ website, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.1 }}
      className="card-glass group rounded-xl overflow-hidden flex flex-col h-full transform transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_10px_30px_-10px_rgba(245,158,11,0.2)]"
    >
      <div className="relative h-48 overflow-hidden">
        <img
          src={website.imageUrl}
          alt={website.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-80" />
        <div className="absolute bottom-3 left-3">
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-amber-500/20 text-amber-500 text-xs font-medium border border-amber-500/20 backdrop-blur-sm">
            <Tag size={12} />
            {website.category}
          </span>
        </div>
      </div>

      <div className="p-5 flex-1 flex flex-col">
        <h3 className="text-xl font-bold text-white mb-2 line-clamp-1 group-hover:text-amber-500 transition-colors">
          {website.name}
        </h3>
        <p className="text-slate-400 text-sm mb-4 line-clamp-3 flex-1">
          {website.description}
        </p>

        <a
          href={website.url}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-auto inline-flex items-center justify-center gap-2 w-full py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all border border-slate-700 hover:border-slate-600 group-hover:border-amber-500/30"
        >
          Kunjungi Website
          <ExternalLink size={16} />
        </a>
      </div>
    </motion.div>
  );
};
