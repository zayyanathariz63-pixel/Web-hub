import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Home } from './pages/Home';
import { Admin } from './pages/Admin';
import { RulesModal } from './components/RulesModal';
import { SubmitModal } from './components/SubmitModal';
import { SuggestionModal } from './components/SuggestionModal';
import { AdminLoginModal } from './components/AdminLoginModal';

const AppContent: React.FC = () => {
  const { hasSeenRules } = useApp();
  const [isRulesOpen, setIsRulesOpen] = useState(false);
  const [isSubmitOpen, setIsSubmitOpen] = useState(false);
  
  // Auto-open rules if not seen
  useEffect(() => {
    if (!hasSeenRules) {
      // Small delay for better UX
      const timer = setTimeout(() => setIsRulesOpen(true), 500);
      return () => clearTimeout(timer);
    }
  }, [hasSeenRules]);

  return (
    <>
      <Navbar 
        onOpenRules={() => setIsRulesOpen(true)} 
        onOpenSubmit={() => setIsSubmitOpen(true)} 
      />
      
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/admin" element={<Admin />} />
      </Routes>

      <RulesModal 
        isOpen={isRulesOpen} 
        onClose={() => setIsRulesOpen(false)} 
        isMandatory={!hasSeenRules}
      />
      
      <SubmitModal 
        isOpen={isSubmitOpen} 
        onClose={() => setIsSubmitOpen(false)} 
      />
      <SuggestionModal />
      <AdminLoginModal />
    </>
  );
};

export function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </AppProvider>
  );
}
