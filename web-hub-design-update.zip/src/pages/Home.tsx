import React from 'react';
import { useApp } from '../context/AppContext';
import { WebsiteCard } from '../components/WebsiteCard';
import { Sparkles } from 'lucide-react';

export const Home: React.FC = () => {
  const { recommendedWebsites } = useApp();

  return (
    <div className="container mx-auto px-4 py-8 pt-24 min-h-screen flex flex-col">
      {/* Hero / Intro */}
      <div className="text-center mb-12 space-y-4">
        <h1 className="text-4xl md:text-5xl font-extrabold text-white tracking-tight">
          Jelajahi <span className="bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">Semesta</span> Website
        </h1>
        <p className="text-slate-400 max-w-2xl mx-auto text-lg">
          Temukan koleksi website terbaik, inspiratif, dan bermanfaat yang dikurasi oleh komunitas.
        </p>
      </div>

      {/* Recommendations Grid */}
      <div className="mb-8 flex items-center gap-2">
        <Sparkles className="text-amber-500" size={20} />
        <h2 className="text-xl font-bold text-white">Rekomendasi Untukmu</h2>
      </div>

      {recommendedWebsites.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {recommendedWebsites.map((website, index) => (
            <WebsiteCard key={website.id} website={website} index={index} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-slate-900/50 rounded-2xl border border-slate-800 mb-16">
          <p className="text-slate-500">Belum ada website yang tersedia.</p>
        </div>
      )}

    </div>
  );
};
